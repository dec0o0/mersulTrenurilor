/* Jason - IBRA 2012-02-18
    Bible Navigation and Titles Library */

/* Declare Localised variables (we can change these for other languages) */
/* NOTE: Limitation: The unicode characters chosen for book names etc must be supported by the system font */
/* The same limitation does not apply to the actual book content however.  Worst case you may have to name your books in English or simplify */
var aBooks = [
            ['matthew', 'متى', 'Matthew', 28, false],
            ['mark', 'مرقوس', 'Mark', 16, false],
            ['luke', 'لُوقا', 'Luke', 24, false],
            ['john', 'يوحنا', 'John', 21, true],
            ['acts', 'اَعمال د رسُولانو', 'Acts', 28, true],
            ['romans', 'رُوميانو', 'Romans', 16, true],
            ['1-corinthians', 'کورنتيانو اول', '1 Corinthians', 16, false],
            ['2-corinthians', 'کورنتيانو دويم', '2 Corinthians', 13, false],
            ['galatians', 'ګلتيانو', 'Galatians', 6, false],   /* NOTE: if in ګلتيانو the Pashto GAF is not supported by the system fonts then could use کلتيانو */
            ['ephesians', 'اِفِسيانو', 'Ephesians', 6, true],
            ['philippians', 'فيليپيانو', 'Philippians', 4, false],
            ['colossians', 'کولوسيانو', 'Colossians', 4, false],
            ['1-thessalonians', 'تِسالونيکانو اول', '1 Thessalonians', 5, false],
            ['2-thessalonians', 'تِسالونيکانو دويم', '2 Thessalonians', 3, false],
            ['1-timothy', 'تيموتيوس اول', '1 Timothy', 6, false],
            ['2-timothy', 'تيموتيوس دويم', '2 Timothy', 4, false],
            ['titus', 'تيطوس', 'Titus', 3, false],
            ['philemon', 'فيليمون', 'Philemon', 1, false],
            ['hebrews', 'عبرانيانو', 'Hebrews', 13, false],
            ['james', 'يعقُوب', 'James', 5, false],
            ['1-peter', 'پطروس رسُول اول', '1 Peter', 5, false],
            ['2-peter', 'پطروس رسُول دويم', '2 Peter', 3, false],
            ['1-john', 'يوحنا رسُول اول', '1 John', 5, false],
            ['2-john', 'يوحنا رسُول دويم', '2 John', 1, false],
            ['3-john', 'يوحنا رسُول دريم', '3 John', 1, false],
            ['jude', 'يهوداه', 'Jude', 1, true],
            ['revelation', 'مُکاشفه', 'Revelation', 22, false]
        ];
var aNumbers = [ '۰','۱','۲','۳','۴','۵','۶','۷','۸','۹' ];
var bRTL = true; /* Use RTL rather than LTR */
var bNumbersReverse = false; /* Number reversal for some RTL languages */
var TITLE_BOOK = 'کتاب'; /* Book */
var TITLE_CHAPTER = 'باب'; /* Chapter */
var TITLE_SELECTBOOK = 'کتاب:'; /* Select Book: */
var TITLE_SELECTCHAPTER = 'باب:'; /* Select Chapter: */
var TITLE_ABOUT = 'معلومات'; /* About (here I've translated as information) */
var ABOUT_TEXT ='<font size="4">'+'پښتو إنجيل'+"</font><br />"+'<font size="2">Pashto Injil (New Testament)</font>'+"<br /><br />" + '<font size="1">© PBS, Pashto Zeray / IBRA</font>';

/* Declare variables for understanding the above localised arrays */
var cId = 0;  var cName = 1;  var cEnglishName = 2;  var cNoChapters = 3; var cHasAudio = 4;  var cChapters = 5; /* cChapters is populated dynamically */

/* Set initial defaults */
var iBook = 0;
var iNumBooks = aBooks.length
var iChapter = 0;
var xmlBook = '';

// Load initial data
readBookXml();

/* Declare utility functions used internally to this library */
function toLocalNo(iNumber) {
    var sLatinNum = '' + iNumber;
    var sLocalNum = '';
    var iDigit = 0;
    if (bNumbersReverse) {
        for (var n=sLatinNum.length-1; n>-1; n--) {
            iDigit = parseInt(sLatinNum.charAt(n));
            sLocalNum += aNumbers[iDigit];
        }
    } else {
        for (var n=0; n<sLatinNum.length; n++) {
            iDigit = parseInt(sLatinNum.charAt(n));
            sLocalNum += aNumbers[iDigit];
        }
    }
    return sLocalNum;
}

function readBookXml() {
    var httpReq = new XMLHttpRequest();
    var sBookFile = 'xml/'+aBooks[iBook][cId]+ '.xml';
    httpReq.onreadystatechange = function() {
        if(httpReq.readyState == XMLHttpRequest.DONE) {
            var xmlBook = httpReq.responseXML.documentElement;
            var aChapters = [];
            var sThisBookName = '';
            for (var ii = 0; ii < xmlBook.childNodes.length; ++ii) {
                if (xmlBook.childNodes[ii].nodeName == 'chapter') {
                    aChapters.push(xmlBook.childNodes[ii].firstChild.nodeValue);
                } else if (xmlBook.childNodes[ii].nodeName == 'name') {
                    sThisBookName = xmlBook.childNodes[ii].firstChild.nodeValue;
                }
            }
            var iProcessingBook = iBook;
            if (aBooks[iProcessingBook][cId] == sThisBookName) {
                // we've read in the right file (would always be the case unless user UI usage is pretty quick or machine pretty slow)
                aBooks[iProcessingBook][cChapters] = aChapters;
                var iProcessingChapter = iChapter;
                if (iProcessingBook == iBook) { // quick final check in case it just changed
                    mainPage.text = aBooks[iProcessingBook][cChapters][iProcessingChapter];
                    mainPage.title = getPageTitle();
                    mainPage.titleEn = getPageTitleEn();
                }
            }
       //     console.log('XML for book: '+sThisBookName + ' consists of '+aChapters.length+ ' chapters');

        } // no else as no other states are of interest to our app
     };
    httpReq.open("GET", sBookFile); // this only gets headers
    httpReq.send();  // this gets the file back
}

/* Declare external functions (would be methods/properties as get/set, feel free to OO if need be */


/* MenuItems */
function buildBookMenu(oDialog) {
    var sList = '';
    var sRTL = '';
    var sStr = '';
    var sEnStr = '';
    if (bRTL) {
        sRTL = String.fromCharCode(8207);
    }
    for(var n=0; n<aBooks.length; n++) {
        sStr = sRTL+aBooks[n][cName];
        sEnStr = aBooks[n][cEnglishName];
        sList += 'ListElement { name: "'+sStr+'";  nameEn: "'+sEnStr+'" }'+"\n";
    }
    sList = 'import QtQuick 1.1\n import com.nokia.meego 1.0\n '+"ListModel {\n   id: bookListModel\n" +sList + "\n}";
    var  oListElement = Qt.createQmlObject(sList, oDialog);
    return oListElement;
}
function buildChapterMenu(oDialog) {
    var sList = '';
    var sRTL = '';
    if (bRTL) {
        sRTL = String.fromCharCode(8207);
    }

    for(var n=0; n<getNumChapters(); n++) {

        sList += 'ListElement { name: "'+sRTL+toLocalNo(n+1)+'";  nameEn: "'+ (n+1) +'" }'+"\n";
    }
    sList = 'import QtQuick 1.1\n import com.nokia.meego 1.0\n '+"ListModel {\n  /* id: chapterListModel\n*/" +sList + "\n}";
    var  oListElement = Qt.createQmlObject(sList, oDialog);
    return oListElement;
}


/* Number of chapters in current book */
function getNumChapters() {
    return aBooks[iBook][cNoChapters];
}

function getBookName(n) {
    return aBooks[n][cName];
}

/* Title of current page */
function getPageTitle() {
    var sBook = aBooks[iBook][cName];
    var sChapter = toLocalNo(iChapter+1); /* Add one so as not to show as chapter 0 */
    return (' '+sBook+' '+sChapter);
}

/* English Title of current page */
function getPageTitleEn() {
    var sBook = aBooks[iBook][cEnglishName];
    var sChapter = (iChapter+1); /* Add one so as not to show as chapter 0 */
    return (' '+sBook+' '+sChapter);
}

/* Text of current page */
function setPageText() {
    if (!(aBooks[iBook][cNoChapters])) {
        // need to read in the XML for this book
        readBookXml();
    } else {
        mainPage.text = aBooks[iBook][cChapters][iChapter];
    }

    scrollToTop();
    /* Here is the next tricky bit... we need to get the data from a file */
  //  return '<font size="4" color="#000055"><b>کلام جُسه شو</b></font><br><font size="1" color="#550000">١</font> په ازل کښے کلام وُو اَؤ کلام دَ خُدائے څخه وُو اَؤ کلام خُدائے وُو، <font size="1" color="#550000">٢</font> دغه په ازل کښے دَ خُدائے څخه وُو. <font size="1" color="#550000">٣</font> اَؤ دَ هغۀ په وسيله ټول څيزُونه په وجُود کښے راغلل. څۀ چه په وجُود کښے راغلل،يو څيز هم بغير دَ هغۀ نه په وجُود کښے رانۀ غے. <font size="1" color="#550000">٤</font> په هغۀ کښے ژوندون وُو اَؤ هم دغه ژوندُون دَ بنى آدمو نُور وُو. <font size="1" color="#550000">٥</font> اَؤ نُور په تيارۀ کښے ځليږى اَؤ تيارۀ پرے هيڅ کله هم غالبه نۀ شوه.<br><font size="1" color="#550000">٦</font> يحيىٰ نومے يو سړے دَ خُدائے له طرفه راغے. <font size="1" color="#550000">٧</font> هغه دَ نور دَ شهادت دَ پاره راغے چه ټول خلق دَ هغۀ په وسيله ايمان راؤړى. <font size="1" color="#550000">٨</font> هغه په خپله خو نُور نۀ وُو ليکن دَ نور دَ شهادت دَ پاره راغے. <font size="1" color="#550000">٩</font> اَؤ حقيقى نُور چه هر يو بنى آدم روښانه کوى هغه لا دُنيا ته راتلونکے وُو.<br><font size="1" color="#550000">١٠</font> هغه په دُنيا کښے وُو اَؤ دُنيا دَ هغۀ په وسيله په وجُود کښے راغله خو دُنيا هغه ونۀ پيژندلو. <font size="1" color="#550000">١١</font> هغه خپل ځائے ته راغے خو دَ هغۀ خپلوانو هغه قبُول نۀ کړو. <font size="1" color="#550000">١٢</font> خو کومو خلقو چه قبُول کړو هغوئ ته ئے دا حق ورکړو چه دَ خُدائے اَؤلاد شى يعنى هغوئ چه دَ هغۀ په نامه ايمان راؤړى، <font size="1" color="#550000">٣١</font> چه نۀ له وينے نه اَؤ نۀ له جسمانى شوق اَؤ نۀ دَ اِنسانى پلار په اِرادے بلکه له خُدائے نه پيدا شو.<br><font size="1" color="#550000">١٤</font> نو کلام جُسه شو اَؤ هغه زمُونږ سره اوسيدو اَؤ مُونږ دَ هغۀ لوئى وليده،داسے لوئى لکه چه دَ پلار دَ يو زوئے چه په فضل اَؤ حقيقت معمُور وى.<br><font size="1" color="#550000">١٥</font> يحيىٰ دَ هغۀ په حق کښے شاهدى وکړله. هغۀ په چغو ووئيل چه”دا هغه سړے دے چه ما ئے ذکر کړے وُو يعنے دا چه هغه څوک چه له ما نه وروستو راځى هغه له ما نه وړُومبے شو،زَۀ چه پيدا کيدم نو هغه وُو.“<br><font size="1" color="#550000">١٦</font> ځکه چه مُونږ ټولو دَ هغۀ دَ کُلهمى معمُورتيا نه په فضل باندے فضل ومُوندلو. <font size="1" color="#550000">١٧</font> ځکه چه شريعت دَ مُوسىٰ په وسيله ورکړے شو خو فضل اَؤ حقيقت دَ عيسىٰ مسيح په وسيله راغلل. <font size="1" color="#550000">١٨</font> خُدائے چرے هيچا نۀ دے ليدلے بے له خُدائے دَ يو زوئے نه،هغه څوک چه دَ پلار په غيږ کښے دے اَؤ هم پلار هغۀ ښکاره کړے دے.<br>';
}

function getNumBooks() {
    return iNumBooks;
}

function scrollToTop() {
    // no point being at the bottom of a new page, you want to be at the top really

    mainPage.contentY = 0;

}

function afterBookChange() {
    // read in the book XML
    readBookXml();

    // redraw chapter list based on book change
   // console.log(chooseChapter.model);
    chooseChapter.model.clear();

    //TODO: Repopulate it with append rather than rebuild
    chooseChapter.model = buildChapterMenu(chooseChapter);

  //  console.log('reloaded chapters for book '+iBook+' length '+getNumChapters());
  //   console.log(chooseChapter.model);
}

/* Move to next page */
function nextPage() {
    iChapter++;
    if (iChapter > getNumChapters()-1) {
        if (iBook+1 >iNumBooks-1) {
            iChapter--; /* don't navigate anywhere - end of books! */
            return false;
        } else {
            iBook ++;
            iChapter = 0;
            afterBookChange();
            return true;
        }
    } else {
        mainPage.title = getPageTitle();
        mainPage.titleEn = getPageTitleEn();
        setPageText();
        return true;
    }
}

/* Move to previous page */
function prevPage() {
    iChapter--;
    if (iChapter < 0) {
        if (iBook-1 < 0) {
            iChapter++; /* don't navigate anywhere - start of books! */
            return false;
        } else {
            iBook--
            iChapter = getNumChapters()-1;
            afterBookChange();
            return true;
        }
    } else {
        mainPage.title = getPageTitle();
        mainPage.titleEn = getPageTitleEn();
        setPageText();
        return true;
    }
}

function firstPage() {
    var bFire = false;
    if (iBook != 0) {
        bFire = true;
    }
    iChapter = 0;
    iBook = 0;
    if (bFire) {
        afterBookChange();
        return true;
    } else {
        mainPage.title = getPageTitle();
        mainPage.titleEn = getPageTitleEn();
        setPageText();
    }
}

function lastPage() {
    var bFire = false;
    if (iBook != iNumBooks-1) {
        bFire = true;
    }
    iBook = iNumBooks-1;
    iChapter = getNumChapters()-1;
    if (bFire) {
        afterBookChange();
        return true;
    } else {
        mainPage.title = getPageTitle();
        mainPage.titleEn = getPageTitleEn();
        setPageText();
    }
}

function navBook(iBookNo) {
    var bFire = false;
    if (iBook != iBookNo) {
        bFire = true;
    }
    iBook = iBookNo;
    iChapter = 0;
    if (bFire) {
        afterBookChange();
    } else {
        mainPage.title = getPageTitle();
        mainPage.titleEn = getPageTitleEn();
        setPageText();
    }
    return true;
}

function navChapter(iChapterNo) {
    if (iChapterNo > getNumChapters()-1) {
        iChapter = getNumChapters()-1;
    } else if (iChapterNo < 0) {
        iChapter = 0;
    } else {
        iChapter = iChapterNo;
    }
    mainPage.title = getPageTitle();
    mainPage.titleEn = getPageTitleEn();
    setPageText();
    return true;
}

function modal(bSwitch) {
    if (!bSwitch) {
        appWindow.showToolBar = true;
        commonTools.enabled = true;
        commonTools.visible = true;
    } else {
        appWindow.showToolBar = false;
        commonTools.enabled= false;
        commonTools.visible = false;
    }

}
